#!/bin/bash

ASPNETCORE_ENVIROMNENT=Production

dotnet index.dll